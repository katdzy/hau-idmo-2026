<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('employments', function (Blueprint $table) {
            $table->string('id') ->primary();
            $table->string('emp_id'); 
            $table->string('company'); 
            $table->string('position'); 
            $table->date('date_hired'); 
            $table->date('date_resigned'); 
            $table->longText('reason');
            $table->string('status'); 
            $table->string('attachment'); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employments');
    }
};

<x-guest-layout>
    <div class="mb-4 text-sm text-gray-600 dark:text-gray-400">
        {{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.') }}
    </div>

    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <form method="POST" action="{{ route('password.email') }}">
        @csrf

        <!-- Email Address -->
        <div>
            <x-input-label for="email" :value="__('Email')" />
            <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autofocus />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Google reCAPTCHA Widget -->
        <div class="mt-4">
            <div class="g-recaptcha" data-sitekey="{{ env('RECAPTCHA_SITE_KEY') }}"></div>
            <x-input-error :messages="$errors->get('captcha')" class="mt-2" />
        </div>

        <div class="flex items-center justify-end gap-4 mt-4">
            <!-- Back to log in button -->
            <x-secondary-button 
                class="text-white px-4 py-2 rounded hover:opacity-80"
                style="background-color: #70121D;"
                onclick="window.location='{{ route('login') }}'">
                {{ __('Back to Login') }}
            </x-secondary-button>
            
            <!-- Email Pssword Button -->
            <x-primary-button>
                {{ __('Email Password Reset Link') }}
            </x-primary-button>
        </div>
    </form>

    <!-- Load the reCAPTCHA API JavaScript -->
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</x-guest-layout>

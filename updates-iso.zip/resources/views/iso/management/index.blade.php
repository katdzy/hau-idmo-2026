<x-app-layout>
<!-- Management Dashboard -->
<div class="min-h-screen">
    <div class="container mx-auto">
        <div class="con-box">
            <!-- Success and Message -->
            @if (session('success') || session('msg'))
                <div class="flex items-center p-4 mb-4 text-emerald-800 border-t-4 border-emerald-300 bg-emerald-50 rounded-lg shadow-sm" role="alert">
                    <svg class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                    <div class="ml-3 text-sm font-medium">{{ session('success') ?? session('msg') }}</div>
                </div>
            @endif
            <!-- Error message -->
            @if (session('error'))
                <div class="flex items-center p-4 mb-4 text-red-800 border-t-4 border-red-300 bg-emerald-50 red-lg shadow-sm" role="alert">
                    <svg class="flex-shrink-0 w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <div class="ml-3 text-sm font-medium">{{ session('error') }}</div>
                </div>
            @endif
            <!-- Header -->
            <div class="w-[95%] px-4 flex my-4 items-center">
                <img src="{{ asset('images/logos/school/soc_logo.png') }}" class="w-[100px] h-[100px] mr-2"/>
                <div class="w-full flex flex-col justify-center">
                    <h1 class="text-[1.5rem] font-bold leading-tight text-purple-700">Document Management System</h1>
                    <span class="text-gray-500 text-sm">Registered Documents Dashboard</span>
                </div>
                <div class="w-full flex gap-4">
                    <!-- Switch to IDC Admin Dashboard -->
                    <a href="{{ route('iso.idc.dashboard') }}" class="bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded-lg font-semibold">
                        Switch to IDC Admin Dashboard
                    </a>
                    <!-- Switch to Document Handler Dashboard -->
                    <a href="{{ route('iso.document') }}" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold">
                        Switch to Document Handler
                    </a>
                </div>
            </div>
            <hr class="w-full opacity-100">

            <!-- Summary Statistics Cards -->
            <div class="w-[95%] grid grid-cols-3 gap-4 px-4 py-4">
                <!-- Total Document Card -->
                <div class="bg-gradient-to-br from-blue-50 to blue-100 border border-blue-200 rounded-lg p-4 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-blue-600 font-medium mb-1">Total Registered Documents</p>
                            <h3 class="text-3xl font-bold text-blue-700">{{ number_format($totalDocuments) }}</h3>
                        </div>
                        <!-- Document Icon -->
                        <div class="bg-blue-500 text-white rounded-full p-3">
                            <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9 2a2 2 0 00-2 2v8a2 2 0 002 2h6a2 2 0 002-2V6.414A2 2 0 0016.414 5L14 2.586A2 2 0 0012.586 2H9z"/>
                                <path d="M3 8a2 2 0 012-2v10h8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <!-- Total Active Documents -->
                <div class="bg-gradient-to-br from-emerald-50 to emerald-100 border border-emerald-200 rounded-lg p-4 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-emerald-600 font-medium mb-1">Total Active Documents</p>
                            <h3 class="text-3xl font-bold text-emerald-700">{{ number_format($activeDocuments) }}</h3>
                        </div>
                        <!-- Icon -->
                        <div class="bg-emerald-500 text-white rounded-full p-3">
                            <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                    </div>
                </div>
                
                <!-- Original Documents Card -->
                <div class="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-4 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-green-600 font-medium mb-1">Original Documents</p>
                            <h3 class="text-3xl font-bold text-green-700">{{ number_format($originalDocuments) }}</h3>
                        </div>
                        <div class="bg-green-500 text-white rounded-full p-3">
                            <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V7.414A2 2 0 0015.414 6L12 2.586A2 2 0 0010.586 2H6zm5 6a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V8z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <!-- Revised Documents Card -->
                <div class="bg-gradient-to-br from-yellow-50 to-yellow-100 border border-yellow-200 rounded-lg p-4 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-yellow-600 font-medium mb-1">Documents with Revision</p>
                            <h3 class="text-3xl font-bold text-yellow-700">{{ number_format($revisedDocuments) }}</h3>
                        </div>
                        <div class="bg-yellow-500 text-white rounded-full p-3">
                            <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                    </div>
                </div>
                <!-- Deleted Documents Card -->
                 <div class="bg-gradient-to-br from-red-50 to-red-100 border border-red-200 rounded-lg p-4 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-red-600 font-medium mb-1">Total Deleted Documents</p>
                            <h3 class="text-3xl font-bold text-red-700">{{ number_format($deletedDocuments) }}</h3>
                        </div>
                        <!-- Icon -->
                        <div class="bg-red-500 text-white rounded-full p-3">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-6">
                                <path fill-rule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 0 1 3.878.512.75.75 0 1 1-.256 1.478l-.209-.035-1.005 13.07a3 3 0 0 1-2.991 2.77H8.084a3 3 0 0 1-2.991-2.77L4.087 6.66l-.209.035a.75.75 0 0 1-.256-1.478A48.567 48.567 0 0 1 7.5 4.705v-.227c0-1.564 1.213-2.9 2.816-2.951a52.662 52.662 0 0 1 3.369 0c1.603.051 2.815 1.387 2.815 2.951Zm-6.136-1.452a51.196 51.196 0 0 1 3.273 0C14.39 3.05 15 3.684 15 4.478v.113a49.488 49.488 0 0 0-6 0v-.113c0-.794.609-1.428 1.364-1.452Zm-.355 5.945a.75.75 0 1 0-1.5.058l.347 9a.75.75 0 1 0 1.499-.058l-.346-9Zm5.48.058a.75.75 0 1 0-1.498-.058l-.347 9a.75.75 0 0 0 1.5.058l.345-9Z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </div>
                </div>
                <!-- Superseded Documents Card -->
                 <div class="bg-gradient-to-br from-rose-50 to-rose-100 border border-rose-200 rounded-lg p-4 shadow-sm">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-rose-600 font-medium mb-1">Total Superseded Documents</p>
                            <h3 class="text-3xl font-bold text-rose-700">{{ number_format($supersededDocuments) }}</h3>
                        </div>
                        <!-- Icon -->
                        <div class="bg-rose-500 text-white rounded-full p-3">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-6">
                                <path d="M3.375 3C2.339 3 1.5 3.84 1.5 4.875v.75c0 1.036.84 1.875 1.875 1.875h17.25c1.035 0 1.875-.84 1.875-1.875v-.75C22.5 3.839 21.66 3 20.625 3H3.375Z" />
                                <path fill-rule="evenodd" d="m3.087 9 .54 9.176A3 3 0 0 0 6.62 21h10.757a3 3 0 0 0 2.995-2.824L20.913 9H3.087Zm6.163 3.75A.75.75 0 0 1 10 12h4a.75.75 0 0 1 0 1.5h-4a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Breakdown cards -->
            <div class="w[95%] grid grid-cols-2 gap-4 px-4 pb-4">
                <!-- By Source Type -->
                <div class="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                    <div class="bg-gray-50 px-4 py-3 border-b border-gray-200">
                        <h5 class="font-bold text-gray-700">By Source Type</h5>
                    </div>
                    <div class="p-4">
                        @forelse($byClassification as $item)
                            <div class="flex justify-between items-center py-2 px-2 mb-2 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                                <div class="flex items-center">
                                    <div class="bg-purple-100 text-purple-600 rounded-full p-2 mr-3">
                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M2 6a2 2 0 012-2h5l2 2h5a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6z"/>
                                        </svg>
                                    </div>
                                    <span class="font-medium text-gray-700">{{ $item->source_type }}</span>
                                </div>
                                <span class="bg-purple-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                                    {{ number_format($item->count) }}
                                </span>
                            </div>
                        @empty
                            <p class="text-gray-400 text-center py-6 italic">No documents registered yet</p>
                        @endforelse
                    </div>
                </div>
                <!-- By Department/Office -->
                <div class="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                    <div class="bg-gray-50 px-4 py-3 border-b border-gray-200">
                        <h5 class="font-bold text-gray-700">Top Departments/Offices</h5>
                    </div>
                    <div class="p-4">
                        @forelse($byDepartment as $item)
                            <li class="flex justify-between items-center py-2.5 px-4 bg-gray-50 rounded-xl hover:bg-white hover:shadow-md hover:ring-1 hover:ring-gray-200 transition-all duration-200 group">
                                <div class="flex items-center min-w-0">
                                    <div class="flex shrink-0 bg-green-100 text-green-600 rounded-lg p-2 mr-3 group-hover:bg-green-600 group-hover:text-white transition-colors">
                                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a1 1 0 110 2h-3a1 1 0 01-1-1v-2a1 1 0 00-1-1H9a1 1 0 00-1 1v2a1 1 0 01-1 1H4a1 1 0 110-2V4zm3 1h2v2H7V5zm2 4H7v2h2V9zm2-4h2v2-2V5zm2 4h-2v2h2V9z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>
                                    <span class="font-medium text-gray-700 text-sm truncate">
                                        {{ $item->originating_section }}
                                    </span>
                                </div>

                                <span class="ml-4 bg-green-500 text-white px-2.5 py-0.5 rounded-full text-xs font-bold tabular-nums">
                                    {{ number_format($item->count) }}
                                </span>
                            </li>
                        @empty
                            <li class="flex flex-col items-center justify-center py-12 px-4 border-2 border-dashed border-gray-200 rounded-xl">
                                <svg class="w-12 h-12 text-gray-300 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                </svg>
                                <p class="text-gray-500 text-sm font-medium">No documents registered yet</p>
                                <p class="text-gray-400 text-xs">New entries will appear here automatically.</p>
                            </li>
                        @endforelse
                    </div>
                </div>
            </div>
            <!-- Filter Button -->
            <div class="w-[95%] px-4 text-center mb-4">
                <button type="button"
                    id="open_filter_modal"
                    class="bg-purple-500 hover:bg-purple-600 text-white px-8 py-3 rounded-lg font-semibold text-lg shadow-sm transition">
                    Open Filters & View Documents
                </button>
            </div>

            <!-- Documents Table (hidden until filters are applied) -->
            <div class="w-full max-w-[98%] mx-auto px-4 pb-8" id="documents_table_section" style="display:none;">
                <div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
                    <div class="flex flex-col sm:flex-row justify-between items-center p-4 gap-4 border-b border-gray-100 bg-gray-50/50">
                        <div>
                            <h5 class="font-bold text-gray-80 flex-items-center gap-2">
                                <span class="w-2 h-5 bg-indigo-500 rounded-full"></span>
                                Filtered Documents
                            </h5>
                            <p class="text-xs text-gray-500 mt-0.5">Showing results based on your current selection</p>
                        </div>
                        <button type="button"
                                onclick="clearFilters()"
                                class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 text-sm font-semibold rounded-lg shadow-sm transition-all focus:ring-2 focus:ring-indigo-500 outline-none">
                            <svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="bg-gray-50/80 border-b border-gray-200">
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Document Code</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Document Title</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Source</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Type</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Dept/Office</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Rev.</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Registered</th>
                                </tr>
                            </thead>
                            <tbody id="documents_table_body" class="divide-y divide-gray-100 text-sm text-gray-600">
                                <!-- WIll be populated via AJAX -->
                            </tbody>
                        </table>
                    </div>
                    <div id="no_results_message" class="flex flex-col items-center justify-center py-16 px-4" style="display:none;">
                        <div class="bg-gray-100 p-4 rounded-full mb-2">
                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                        </div>
                        <p class="text-gray-600 font-medium">No documents match your filters</p>
                        <p class="text-gray-400 text-sm mt-1">Try adjusting your search criteria or clearing all filters.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Filter Modal -->
@include('iso.management.partials.filter-modal')
</x-app-layout>

<style>
    .container { 
        width: 100%;
        display: flex; 
        justify-content: center;
        padding: 2rem 0;
    }
    
    .con-box { 
        border-radius: 10px; 
        width: 95%;
        background-color: white;
        display: flex; 
        flex-direction: column;
        align-items: center;
        padding: 1rem 0;
    }

    .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
        overflow-y: auto;
        padding: 2rem 0;
    }

    .modal-overlay.active {
        display: flex;
    }

    .modal-content {
        background: white;
        border-radius: 10px;
        width: 90%;
        max-width: 900px;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.5rem;
        border-bottom: 1px solid #e5e7eb;
    }

    .modal-body {
        padding: 1.5rem;
    }
</style>

<script>
const specificOfficeOptions = {
    oop: [
        "(OOP) Office of the President",
        "(OOP-AVI) Aviation Insitute",
        "(OOP-CKS) Center for Kapampangan Studies",
        "(OOP-DPO) Data Privacy Office",
        "(OOP-ITC) Institutional Testing and Evaluation Center",
        "(OOP-ITS) Information Technology Systems & Services",
        "(OOP-OIA) Office of International Affairs",
        "(OOP-TRO) Treasury Office",
        "(OOP-UCO) University Chaplain Office"
    ],
    aac: [
        '(AAC) Academic Affairs Office',
        '(AAC-BED) School of Basic Education',
        '(AAC-CJE) College of Criminal Justice Education & Forensics',
        '(AAC-CTL) Center for Teaching & Learning',
        '(AAC-GSR) Graduate Studies & Research',
        '(AAC-IRB) Institutional Review Board',
        '(AAC-LIB) Library Department',
        '(AAC-LMS) Learning Management System',
        '(AAC-SAS) School of Arts & Sciences',
        '(AAC-SBA) School of Business & Accountancy',
        '(AAC-SEA) School of Engineering & Architecture',
        '(AAC-SED) School of Education',
        '(AAC-SNA) SChool of Nursing & Allied Medical Sciences',
        '(AAC-SOC) School of Computing',
        '(AAC-STM) School of Hospitality & Tourism Management',
        '(AAC-URO) University Research Office'
    ],
    oie: [
        '(OIE-DMO) Institutional Database Management Office',
        '(OIE-IDC) Insitutional Document Controller',
        '(OIE-IPR) Institutional Research, Planning & Publications Office',
        '(OIE-QAO) Quality Assurance Office'
    ],
    cfs: [
        '(CFS-CES) Office of the Community Extension Services',
        '(CFS-CLE) Christian Living Education',
        '(CFS-CMO) Campus Ministry Office'
    ],
    hro: [
        '(HRO-HRD) Human Resource Development',
        '(HRO-HRM) Recruitment and Maintenance'
    ],
    frm: [
        '(FRM) Finance and Resource Management Office',
        '(FRM-ACC) Accounts & Collection',
        '(FRM-ASE) Ancillary Services',
        '(FRM-ATO) Accounting',
        '(FRM-GRT) Grants Accounttant',
        '(FRM-PAO) Payroll'
    ],
    rss: [
        '(RSS-ADO) Admissions Office'
    ],
    ssa: [
        '(SSA-CPO) Career and Placement Office',
        '(SSA-MDS) Medical and Dental Services',
        '(SSA-SAO) Student Affairs',
        '(SSA-SGO) Scholarships & Grants',
        '(SSA-UGC) University Guidance Center',
        '(SSA-USO) University Sports'
    ],
    eac: [
        '(EAC) External Affairs Office',
        '(EAC-ARO) Alumni Relations Office',
        '(EAC-CRE) Creative Services',
        '(EAC-PAM) Performing Arts and Events Management',
        '(EAC-PRO) Public Relations Office'
    ],
    csd: [
        '(CSD-CSO) Campus Services Office',
        '(CSD-ECM) Engineering Construction and Maintenance',
        '(CSD-MCM) Motorpool/Campus Maintenance',
        '(CSD-PCO) Property Custodianship Office',
        '(CSD-PUO) Purchasing Office',
        '(CSD-SEC) Campus Security',
        '(CSD-VLO) Venues and Logistics Office'
    ],
    aie: [
        '(AIE-ETA) Expanded Tertiary Education, Equivalency & Accreditation',
        '(AIE-SPL) School of Professional Education and Lifelong Learning',
        '(AIE-TBI) Technology Business Incubator - KITTO'
    ]
};
const filterModal = document.getElementById('filter_modal');
const openFilterBtn = document.getElementById('open_filter_modal');
const closeFilterBtn = document.getElementById('close_filter_modal');

// Open Modal
openFilterBtn.addEventListener('click', ()=>{
    filterModal.classList.add('active');
});
// Close modal
closeFilterBtn.addEventListener('click', ()=>{
    filterModal.classList.remove('active');
});
// Close modal when clicking outside
filterModal.addEventListener('click', (e)=>{
    if(e.target === filterModal){
        filterModal.classList.remove('active');
    }
});

// Department Search
const departmentSelect = document.getElementById('filter_department');
const officesContainer = document.getElementById('offices_container');
const officesCheckboxes = document.getElementById('offices_checkboxes');

departmentSelect.addEventListener('change', (e)=>{
    const selectedDept = e.target.value;

    officesCheckboxes.innerHTML = '';
    if(!selectedDept || selectedDept===''){
        officesContainer.style.display = 'none';
        return;
    }

    officesContainer.style.display = 'block';

    const offices = specificOfficeOptions[selectedDept];

    offices.forEach((office) =>{
        const label = document.createElement('label');
        label.className = 'flex items-center bg-white p-2 mb-1 rounded hover:bg-gray-100 cursor-pointer';

        label.innerHTML = `
            <input type="checkbox"
                name="originating_section[]"
                value="${office}"
                class="mr-2 text-purple-500 focus:ring-purple-500">
            <span class="text-sm">${office}</span>
        `;

        officesCheckboxes.appendChild(label);
    });
});

// Clear All filters Button
document.getElementById('clear_all_filters').addEventListener('click', ()=>{
    document.getElementById('filter_form').reset();
    officesContainer.style.display = 'none';
    officesCheckboxes.innerHTML = '';
});

// Apply Filters (AJAX)
document.getElementById('filter_form').addEventListener('submit', (e)=>{
    e.preventDefault();

    const formData = new FormData(e.target);

    // Convert to URL parameters
    const params = new URLSearchParams();

    formData.forEach((value, key) => {
        params.append(key, value);
    });

    fetch(`{{ route('iso.management.documents') }}?${params.toString()}`)
        .then(response => {
            if(!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data=>{
            displayDocuments(data);
            filterModal.classList.remove('active');
            document.getElementById('documents_table_section').style.display = 'block';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to load documents. Please try again.');
        });
});

function displayDocuments(documents){
    const tbody = document.getElementById('documents_table_body');
    const noResults =document.getElementById('no_results_message');

    // Clear exiting rows
    tbody.innerHTML = '';
    if(documents.length === 0){
        noResults.style.display = 'flex';
        return;
    }

    noResults.style.display = 'none';
    documents.forEach((doc) =>{
        const row = createDocumentRow(doc);
        tbody.appendChild(row);
    });
}

function createDocumentRow(doc){
    const tr = document.createElement('tr');
    tr.className = 'border-b bg-gray-50';

    const hasRevisions = doc.current_revision > 0;

    const registeredDate = new Date(doc.registered_at).toLocaleDateString();
    // Status badge colors
    const statusColors = {
        'Active': 'bg-green-100 text-green-800',
        'Superseded': 'bg-yellow-100 text-yellow-800',
        'Deleted' : 'bg-red-100 text-red-800'
    };

    tr.innerHTML = `
        <td class="px-4 py-3 text-sm font-mono text-blue-600">${doc.document_code}</td>
        <td class="px-4 py-3 text-sm">${doc.document_title}</td>
        <td class="px-4 py-3 text-sm">${doc.source_type}</td>
        <td class="px-4 py-3 text-sm">${doc.specific_type}</td>
        <td class="px-4 py-3 text-sm">${doc.originating_section}</td>
        <td class="px-4 py-3 text-sm">
            ${hasRevisions
            ? `<span class="text-purple-600 font-semibold">Rev ${doc.current_revision}</span>`
            : '<span class="text-gray-500">Original</span>'}
        </td>
        <td class="px-4 py-3 text-sm">
            <span class="inline-block px-2 py-1 rounded text-xs ${statusColors[doc.status] || 'bg-gray-100 text-gray-800'}">
                ${doc.status}
            </span>
        </td>
        <td class="px-4 py-3 text-sm text-gray-600">${registeredDate}</td>
    `;
    return tr;
}

function clearFilters(){
    document.getElementById('documents_table_section').style.display = 'none';
    // Reset form
    document.getElementById('filter_form').reset();
}

setTimeout(() => {
    const msg = document.getElementById('msg');
    const errorMsg = document.getElementById('error-msg');
    if(msg) msg.style.display = 'none';
    if(errorMsg) errorMsg.style.display = 'none';
}, 5000);
</script>